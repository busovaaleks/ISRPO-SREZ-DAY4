﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VIN_LIB
{
    public class Class1
    {
        public bool CheckVIN(string vin)
        {
            char[] bukv = { 'А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х', 'A', 'B', 'E', 'K', 'M', 'H', 'O', 'P', 'C', 'T', 'Y', 'X' };

            if (vin.Length == 9 && bukv.Contains(vin.ToCharArray()[0]))
                return true;
            else
                return false;
        }

        public String GetVINCountry(String vin)
        {
            char[] afrika = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };
            char[] azia = { 'J', 'K', 'L', 'M', 'N', 'P', 'R', 'H' };
            char[] evropa = { 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] severnaamerika = { '1', '2', '3', '4', '5' };
            char[] okeania = { '6', '7' };
            char[] uhmaamerika = { '8', '9' };

            char[] South_Africa = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' };
            char[] Cote_d = { 'J', 'K', 'L', 'M', 'N' };
            char[] unassigned = {'P','O' };
            char[] Angola = { 'A', 'B', 'C', 'D', 'E' };
            char[] Kenya = { 'F', 'G', 'H', 'J', 'K' };
            char[] Tanzania = { 'L', 'M', 'N', 'P', 'R' };
            char[] unassigned2 = { 'S', 'O' };
            char[] Benin = { 'A', 'B', 'C', 'D', 'E' };
            char[] Madagascar = {'F', 'G', 'H', 'J', 'K' };
            char[] Tunisia = { 'L', 'M', 'N', 'P', 'R' };
            char[] unassigned3 = {'S','O'};
            char[] Morocco = { 'F', 'G', 'H', 'J', 'K' };
            char[] Zambia = { 'L', 'M', 'N', 'P', 'R' };
            char[] unassigned4 = { 'D', 'O' };
            char[] Ethiopia = { 'A', 'B', 'C', 'D', 'E' };
            char[] Mozambique = { 'F', 'G', 'H', 'J', 'K' };
            char[] unassigned5 = { 'L','O' };
            char[] Ghana = { 'A', 'B', 'C', 'D', 'E' };
            char[] Nigeria = { 'F', 'G', 'H', 'J', 'K' };
            char[] unassigned6 = { 'L','O'};
            char[] unassigned7 = {'A', 'O' };
            char[] unassigned8 = { 'A', 'O' };

            char[] Japan = { 'J' };
            char[] Sri_Lanka = { 'A', 'B', 'C', 'D', 'E', };
            char[] Israel = { 'F', 'G', 'H', 'J', 'K' };
            char[] Korea = { 'L', 'M', 'N', 'P', 'R' };
            char[] Kazakhstan = {'S','O' };
            char[] China = { 'L'};
            char[] India = { 'A', 'B', 'C', 'D', 'E', };
            char[] Indonesia = { 'F', 'G', 'H', 'J', 'K' };
            char[] Thailand = { 'L', 'M', 'N', 'P', 'R' };
            char[] Myanmar = { 'S', 'O' };
            char[] Iran = { 'A', 'B', 'C', 'D', 'E', };
            char[] Pakistan = { 'F', 'G', 'H', 'J', 'K' };
            char[] Turkey = { 'L', 'M', 'N', 'P', 'R' };
            char[] unassigned9 = {'S','O' };
            char[] Philippines = { 'A', 'B', 'C', 'D', 'E', };
            char[] Singapore = { 'F', 'G', 'H', 'J', 'K' };
            char[] Malaysia = { 'L', 'M', 'N', 'P', 'R' };
            char[] unassigned10 = {'S', 'O'};
            char[] United_Arab_Emirates = { 'A', 'B', 'C', 'D', 'E', };
            char[] Taiwan = { 'F', 'G', 'H', 'J', 'K'};
            char[] Vietnam = { 'L', 'M', 'N', 'P', 'R' };
            char[] Saudi_Arabia = { 'S','O' };

            char[] United_Kingdom = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M' };
            char[] Germany = { 'N', 'P', 'R', 'H', 'S', 'T' };
            char[] Poland = { 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] Latvia = { '1', '2', '3', '4' };
            char[] unassigned11 = { '5', 'O' };
            char[] Switzerland = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', };
            char[] Czech_Republic = { 'J', 'K', 'L', 'M', 'N', 'P', };
            char[] Hungary = { 'R', 'H' ,'S', 'T', 'U', 'V' };
            char[] Portugal = { 'W', 'X', 'Y', 'Z' , '1'};
            char[] unassigned12= { '2', '1', '0' };
            char[] unassigned13 = { 'A', 'B', 'C', 'D', 'E', 'F', 'G'};
            char[] Denmark = { 'H', 'J', 'K', 'L', 'M' };
            char[] Ireland = { 'N', 'P', 'R', 'H' , 'S','T'};
            char[] Romania = { 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] unassigned14 = { '1', '2', '3', '4' };
            char[] Slovakia = { '5', '6', '7' };
            char[] unassigned15 = {'8','7','6','5','4','3','2','1','0' };
            char[] Austria = { 'A', 'B', 'C', 'D', 'E' };
            char[] France = { 'F', 'G', 'H' , 'J', 'K', 'L', 'M', 'N', 'P', 'R' };
            char[] Spain = { 'S', 'T', 'U', 'V', 'W' };
            char[] Serbia = { 'X', 'Y', 'Z', '1', '2' };
            char[] Croatia = { '3', '4', '5' };
            char[] Estonia = { '1', '2', '3', '4', '5', '6', '0' };
            char[] Germany_formerlyWestGermany = { 'W' };
            char[] Bulgaria = { 'A', 'B', 'C', 'D', 'E' };
            char[] Greece = { 'F', 'G', 'H', 'J', 'K' };
            char[] Netherlands = { 'L', 'M', 'N', 'P', 'R' };
            char[] RussiaUSSR = { 'S', 'T', 'U', 'V', 'W', };
            char[] Luxembourg = { 'W', 'X', 'Y', 'Z','1','2' };
            char[] Russia = {'1', '2', '3','0' };
            char[] Belgium = { 'A', 'B', 'C', 'D', 'E' };
            char[] Finland = { 'F', 'G', 'H', 'J', 'K' };
            char[] Malta = { 'L', 'M', 'N', 'P', 'R' };
            char[] Sweden = { 'S', 'T', 'U', 'V', 'W' };
            char[] Norway = { 'X', 'Y', 'Z', '1', '2' };
            char[] Belarus = { '3', '4', '5' };
            char[] Ukraine = { '1', '2', '3', '4', '5', '6', '0' };
            char[] Italy = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'R' };
            char[] unassigned16 = { 'S', 'T', 'U', 'V', 'W' };
            char[] Slovenia = { 'X', 'Y', 'Z', '1', '2' };
            char[] Lithuania = { '3', '4', '5' };
            char[] unassigned17 = { '1', '2', '3', '4', '5', '6', '0' };

            char[] United_States = { '1', '4', '5' };
            char[] Canada = { '2' };
            char[] Mexico = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H' , 'J', 'K', 'L', 'M', 'N', 'P', 'R', 'H', 'S', 'T', 'U', 'V', 'W' };
            char[] Costa_Rica = { 'X', 'Y', 'Z', '1', '2', '3', '4', '5' , '6','7'};
            char[] CaymanIslands = { '8', '9' };
            char[] unassigned18 = { '0' };

            char[] Australia = { '6' };
            char[] New_Zealand = { '7' };

            char[] Argentina = { 'A', 'B', 'C', 'D', 'E' };
            char[] Chile = { 'F', 'G', 'H', 'J', 'K' };
            char[] Ecuador = { 'L', 'M', 'N', 'P', 'R' };
            char[] Peru = { 'S', 'T', 'U', 'V', 'W' };
            char[] Venezuela = { 'X', 'Y', 'Z', '1', '2' };
            char[] unassigned19 = { '1', '2', '3' ,'0'};
            char[] Brazil = { 'A', 'B', 'C', 'D', 'E' };
            char[] Colombia = { 'F', 'G', 'H', 'J', 'K' };
            char[] Paraguay = { 'L', 'M', 'N', 'P', 'R' };
            char[] Uruguay = { 'S', 'T', 'U', 'V', 'W' };
            char[] Trinidad_Tobago = { 'X', 'Y', 'Z', '1', '2' };
            char[] Brazil1 = { '3', '4', '5', '6', '7','8','9' };
            char[] unassigned20 = { '0' };


            if (afrika.Contains(vin.ToCharArray()[0]))
            {
                if (South_Africa.Contains(vin.ToCharArray()[1]))
                    return "South Africa";
                else
                    if (Cote_d.Contains(vin.ToCharArray()[1]))
                    return "Cote d'Ivoire";
                else
                    if (unassigned.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Angola.Contains(vin.ToCharArray()[1]))
                    return "Angola";
                else
                    if (Kenya.Contains(vin.ToCharArray()[1]))
                    return "Kenya";
                else
                    if (Tanzania.Contains(vin.ToCharArray()[1]))
                    return "Tanzania";
                else
                    if (unassigned2.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Benin.Contains(vin.ToCharArray()[1]))
                    return "Benin";
                else
                    if (Madagascar.Contains(vin.ToCharArray()[1]))
                    return "Madagascar";
                else
                    if (Tunisia.Contains(vin.ToCharArray()[1]))
                    return "Tunisia";
                else
                    if (unassigned3.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Morocco.Contains(vin.ToCharArray()[1]))
                    return "Morocco";
                else
                    if (Zambia.Contains(vin.ToCharArray()[1]))
                    return "Zambia";
                else
                    if (unassigned4.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Ethiopia.Contains(vin.ToCharArray()[1]))
                    return "Ethiopia";
                else
                    if (Mozambique.Contains(vin.ToCharArray()[1]))
                    return "Mozambique";
                else
                    if (unassigned5.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Ghana.Contains(vin.ToCharArray()[1]))
                    return "Ghana";
                else
                    if (Nigeria.Contains(vin.ToCharArray()[1]))
                    return "Nigeria";
                else
                    if (unassigned6.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (unassigned7.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (unassigned8.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    return "unassigned";
            }
            else
            if (azia.Contains(vin.ToCharArray()[0]))
            {
                if (Japan.Contains(vin.ToCharArray()[1]))
                    return "Japan";
                else
                    if (Sri_Lanka.Contains(vin.ToCharArray()[1]))
                    return "Sri Lanka";
                else
                    if (Israel.Contains(vin.ToCharArray()[1]))
                    return "Israel";
                else
                    if (Korea.Contains(vin.ToCharArray()[1]))
                    return "Korea";
                else
                    if (Kazakhstan.Contains(vin.ToCharArray()[1]))
                    return "Kazakhstan";
                else
                    if (China.Contains(vin.ToCharArray()[1]))
                    return "China";
                else
                    if (India.Contains(vin.ToCharArray()[1]))
                    return "India";
                else
                    if (Indonesia.Contains(vin.ToCharArray()[1]))
                    return "Indonesia";
                else
                    if (Thailand.Contains(vin.ToCharArray()[1]))
                    return "Thailand";
                else
                    if (Myanmar.Contains(vin.ToCharArray()[1]))
                    return "Myanmar";
                else
                    if (Iran.Contains(vin.ToCharArray()[1]))
                    return "Iran";
                else
                    if (Pakistan.Contains(vin.ToCharArray()[1]))
                    return "Pakistan";
                else
                    if (Turkey.Contains(vin.ToCharArray()[1]))
                    return "Turkey";
                else
                    if (unassigned9.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Philippines.Contains(vin.ToCharArray()[1]))
                    return "Philippines";
                else
                    if (Singapore.Contains(vin.ToCharArray()[1]))
                    return "Singapore";
                else
                    if (Malaysia.Contains(vin.ToCharArray()[1]))
                    return "Malaysia";
                else
                    if (unassigned10.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (United_Arab_Emirates.Contains(vin.ToCharArray()[1]))
                    return "United ArabEmirates";
                else
                    if (Taiwan.Contains(vin.ToCharArray()[1]))
                    return "Taiwan";
                else
                    if (Vietnam.Contains(vin.ToCharArray()[1]))
                    return "Vietnam";
                else
                    if (Saudi_Arabia.Contains(vin.ToCharArray()[1]))
                    return "Saudi Arabia";
                else
                    return "unassigned";
            }
            else
            if (evropa.Contains(vin.ToCharArray()[0]))
            {
                if (United_Kingdom.Contains(vin.ToCharArray()[1]))
                    return "United Kingdom";
                else
                    if (Germany_formerlyWestGermany.Contains(vin.ToCharArray()[1]))
                    return "Germany";
                else
                    if (Poland.Contains(vin.ToCharArray()[1]))
                    return "Poland";
                else
                    if (Latvia.Contains(vin.ToCharArray()[1]))
                    return "Latvia";
                else
                    if (unassigned11.Contains(vin.ToCharArray()[1]))
                    return "unassigned";
                else
                    if (Switzerland.Contains(vin.ToCharArray()[1]))
                    return "Switzerland";
                else
                    if (Czech_Republic.Contains(vin.ToCharArray()[1]))
                    return "Czech Republic";
                else
                    if (Hungary.Contains(vin.ToCharArray()[1]))
                    return "Hungary";
                else
                    if (Portugal.Contains(vin.ToCharArray()[1]))
                    return "Portugal";
                else
                    if (Denmark.Contains(vin.ToCharArray()[1]))
                    return "Denmark";
                else
                    if (Ireland.Contains(vin.ToCharArray()[1]))
                    return "Ireland";
                else
                    if (Romania.Contains(vin.ToCharArray()[1]))
                    return "Romania";
                else
                    if (Slovakia.Contains(vin.ToCharArray()[1]))
                    return "Slovakia";
                else
                    if (Austria.Contains(vin.ToCharArray()[1]))
                    return "Austria";
                else
                    if (France.Contains(vin.ToCharArray()[1]))
                    return "France";
                else
                    if (Spain.Contains(vin.ToCharArray()[1]))
                    return "Spain";
                else
                    if (Serbia.Contains(vin.ToCharArray()[1]))
                    return "Serbia";
                else
                    if (Croatia.Contains(vin.ToCharArray()[1]))
                    return "Croatia";
                else
                    if (Estonia.Contains(vin.ToCharArray()[1]))
                    return "Estonia";
                else
                    if (Germany_formerlyWestGermany.Contains(vin.ToCharArray()[1]))
                    return "Germany";
                else
                    if (Bulgaria.Contains(vin.ToCharArray()[1]))
                    return "Bulgaria";
                else
                    if (Greece.Contains(vin.ToCharArray()[1]))
                    return "Greece";
                else
                    if (Netherlands.Contains(vin.ToCharArray()[1]))
                    return "Netherlands";
                else
                    if (RussiaUSSR.Contains(vin.ToCharArray()[1]))
                    return "Russia";
                else
                    if (Luxembourg.Contains(vin.ToCharArray()[1]))
                    return "Luxembourg";
                else
                    if (Russia.Contains(vin.ToCharArray()[1]))
                    return "Russia";
                else
                    if (Belgium.Contains(vin.ToCharArray()[1]))
                    return "Belgium";
                else
                    if (Finland.Contains(vin.ToCharArray()[1]))
                    return "Finland";
                else
                    if (Malta.Contains(vin.ToCharArray()[1]))
                    return "Malta";
                else
                    if (Sweden.Contains(vin.ToCharArray()[1]))
                    return "Sweden";
                else
                    if (Norway.Contains(vin.ToCharArray()[1]))
                    return "Norway";
                else
                    if (Belarus.Contains(vin.ToCharArray()[1]))
                    return "Belarus";
                else
                    if (Ukraine.Contains(vin.ToCharArray()[1]))
                    return "Ukraine";
                else
                    if (Italy.Contains(vin.ToCharArray()[1]))
                    return "Italy";
                else
                    if (Slovenia.Contains(vin.ToCharArray()[1]))
                    return "Slovenia";
                else
                    if (Lithuania.Contains(vin.ToCharArray()[1]))
                    return "Lithuania";
                else
                    return "unassigned";
            }
            else

            if (severnaamerika.Contains(vin.ToCharArray()[0]))
            {
                if (United_States.Contains(vin.ToCharArray()[0]))
                    return "United States";
                else
                    if (Canada.Contains(vin.ToCharArray()[0]))
                    return "Canada";
                else
                    if (Mexico.Contains(vin.ToCharArray()[1]))
                    return "Mexico";
                else
                    if (Costa_Rica.Contains(vin.ToCharArray()[1]))
                    return "Costa Rica";
                else
                    if (CaymanIslands.Contains(vin.ToCharArray()[1]))
                    return "Cayman Islands";
                else
                    return "unassigned";
            }
            else
            if (okeania.Contains(vin.ToCharArray()[0]))
            {
                if (Australia.Contains(vin.ToCharArray()[0]))
                    return "Australia";
                else
                    if (New_Zealand.Contains(vin.ToCharArray()[0]))
                    return "New Zealand";
                return "unassigned";
            }
            else
            if (uhmaamerika.Contains(vin.ToCharArray()[0]))
            {
                if (Argentina.Contains(vin.ToCharArray()[1]))
                    return "Argentina";
                else
                    if (Chile.Contains(vin.ToCharArray()[0]))
                    return "Chile";
                else
                    if (Ecuador.Contains(vin.ToCharArray()[0]))
                    return "Ecuador";
                else
                    if (Peru.Contains(vin.ToCharArray()[0]))
                    return "Peru";
                else
                    if (Venezuela.Contains(vin.ToCharArray()[0]))
                    return "Venezuela";
                else
                    if (Brazil.Contains(vin.ToCharArray()[0]))
                    return "Brazil";
                else
                    if (Colombia.Contains(vin.ToCharArray()[0]))
                    return "Colombia";
                else
                    if (Paraguay.Contains(vin.ToCharArray()[0]))
                    return "Paraguay";
                else
                    if (Uruguay.Contains(vin.ToCharArray()[0]))
                    return "Uruguay";
                else
                    if (Trinidad_Tobago.Contains(vin.ToCharArray()[0]))
                    return "Trinidad & Tobago";
                else
                    if (Brazil.Contains(vin.ToCharArray()[0]))
                    return "Brazil";
                else
                    return "unassigned";
            }
            else
                return "Ошибка";
        }

        public int GetTransportYear(String vin)
        {
            int charCode = (int)vin[10], result = 0;

            Dictionary<bool, int> possibleResults = new Dictionary<bool, int>()
            {
                [char.IsDigit(vin[6]) && char.IsDigit(vin[10])] = 2001 - 49 + charCode,
                [char.IsDigit(vin[6]) && !char.IsDigit(vin[10])] = 1980 - 65 + charCode,
                [!char.IsDigit(vin[6]) && char.IsDigit(vin[10])] = 2031 - 49 + charCode,
                [!char.IsDigit(vin[6]) && !char.IsDigit(vin[10])] = 2010 - 65 + charCode,
            };

            result = possibleResults[true];

            return result;
        }

    }
}

