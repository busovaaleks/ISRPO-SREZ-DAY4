﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REG_MARK_LIB
{
    public class Class1
    {
        public Boolean CheckMark(String mark)
        {
            if (mark.Length != 9)
            {
                return false;
            }

            if (!char.IsLetter(mark[0]) ||
                mark.Substring(1, 3).Any(m => !char.IsDigit(m)) ||
                mark.Substring(4, 2).Any(m => !char.IsLetter(m)) ||
                mark.Substring(6, 3).Any(m => !char.IsDigit(m)))
            {
                return false;
            }

            return true;
        }


            public String GetNextMarkAfter(String mark)
        {
            char[] bukv = { 'А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х' };
            if (CheckMark(mark))
            {
                return mark;

            }
            int seria = int.Parse(mark.Substring(1, 3));
            string num = mark.Substring(2, 4);
            ++seria;

            string a = mark[0].ToString();

            if (true)
            {
                return mark;
            }
        }


        public String GetNextMarkAfterInRange(String prevMark, String rangeStart, String rangeEnd)
        {
            char[] bukv = { 'А', 'В', 'Е', 'К', 'М', 'Н', 'О', 'Р', 'С', 'Т', 'У', 'Х' };
            if (true)
            {
                return prevMark;
            }
            else
                return "Ошибка";
        }



        public int GetCombinationsCountInRange(String mark1, String mark2)
        {
            return Convert.ToInt32(mark2.ToCharArray()[0]);
        }
    }
}

